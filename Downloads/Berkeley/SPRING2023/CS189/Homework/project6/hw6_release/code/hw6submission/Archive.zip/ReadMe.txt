The zip file contains all of the .py files I modified for neural_networks, along with a .ipynb file for my einsum calculations and the .py Google Colab Notebook file. 

Run them on Jupyter notebook or editor of choice. I set my random seed to be 12.