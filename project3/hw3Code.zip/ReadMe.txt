Natalie Kemper HW 3 Read Me:

random.seed(10)

Run the jupyter notebook to execute the code. 

Student ID: 3034516759