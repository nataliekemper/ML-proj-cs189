Run the jupyter notebook as normal. Run everything in order.

Random seed: 10

Kaggle username: nadaleek

Score: 95.5%